#!/bin/bash
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y
echo "Update completed successfully!"
echo "Log saved at logs/update.log"
