#!/bin/bash
# Backup script for system maintenance

BACKUP_SRC="$HOME"
BACKUP_DEST="$HOME/bash-system-maintenance/logs/backup_$(date +%Y-%m-%d).tar.gz"

echo "Creating backup..."
tar -czf $BACKUP_DEST $BACKUP_SRC 2>/dev/null

echo "Backup created successfully!"
echo "File saved at: $BACKUP_DEST"
